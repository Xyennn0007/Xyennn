const chalk = require("chalk")
const fs = require("fs")

//owmner v card
//domain && apikey && capikey && egg sesuai panel klian ya
// subrek channel zick official digital
global.owner = ['-'] //ur owner number
global.ownernomer = "-" //ur owner number2
global.ownername = "ARGA DESAIGN⚡" //ur owner name
global.ytname = "-l" //ur yt chanel name
global.socialm = "GitHub: ZickOfc" //ur github or insta name
global.location = "Indonesia" //ur location
global.codeInvite = "CswK4kvQD1u7SfSmsYfMHZ"
global.domain = '-' // isi dengan domain panel lu
global.apikey = 'ptla_d6gRvv10kpprjxfnH1VXa4WCmZu3L5CNgDQ9TKTEeE7' // Isi Apikey Plta Lu
global.capikey = 'ptlc_wvHn8Vy4cIr6pF5hpR2cvwOqB31mmiWyN4hluoKCxsR' // Isi Apikey Pltc Lu
global.eggsnya = '-' // id eggs yang dipakai
global.location = '1' // id location

//new
global.ownergc = "-"
global.botname = "Arga Desaign⚡"
global.ownerNumber = ["@s.whatsapp.net"]
global.ownerweb = "https://youtube.com/@zickoffc_24"
global.themeemoji = '🪀'
global.wm = "panelku.xyz"
global.packname = "Arga Desaign"
global.author = "Zick\n\n"
global.prefa = ['','!','.','#','&']
global.sessionName = 'session'
global.tekspushkon = ''
global.keyopenai ='iigf'

global.limitawal = {
    premium: "Infinity",
    free: 5
}

//media target
global.thumb = { url: 'https://telegra.ph/file/b19e050965a898051a97e.jpg' }//ur thumb pic
global.defaultpp = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60' //default pp wa

//messages
global.mess = {
    selesai: 'Done !!', 
    owner: 'Khusus Owner',
    private: 'Khusus Private',
    group: 'Khusus Group',
    wait: 'Sebentar..',
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
